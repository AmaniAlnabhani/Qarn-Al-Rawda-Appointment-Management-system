<?php


include('conn.php');
$output = '';


 
 
$genders = ['M'=>'Male','F'=>'Female'];


  $query = "SELECT * FROM patient";
 $result = mysqli_query($conn, $query);
 if(mysqli_num_rows($result) > 0)
 {
  $output .= '
   <table class="table" bordered="2">  
                    <tr>  
                         <th> FirstName</th>  
                         <th> LastName </th>  
                         <th> Gender</th>  
						  <th> Age</th> 
						   
						    <th>Phone Number</th> 
       
                    </tr>
  ';
  while($row = mysqli_fetch_array($result))
  {
   $output .= '
    <tr>  
                         <td>'.$row["FirstName"].'</td>  
                         <td>'.$row["LastName"].'</td>  
                         <td>'.$genders {$row["Gender"]}.'</td>  
                        <td>'.$row["Age"].'</td>  
                           <td>'.$row["PhoneNum"].'</td>
                    </tr>
   ';
  }
  $output .= '</table>';
  header('Content-Type: application/xls');
  header('Content-Disposition: attachment; filename=report_patient.xls');
  echo $output;
 }


?>