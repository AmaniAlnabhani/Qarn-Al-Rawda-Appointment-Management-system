<?php
include('conn.php');
include('mylib.php');
session_start();

$errors=[];
 if( empty($_POST['appdate'])
 && $_POST['m']=='x' && isset($_POST['ts'])){ $errors[]="Please chack "; }


$stat=['C'=>'complet','S'=>'Still'];


	
// $y = $_POST['y'];
$mm=$_POST['ts'];
$m=$_POST['m'];
//$ee=$_GET['$m'];
$appdate = $_POST['appdate'];		
 $qry1 = mysqli_query($conn, "SELECT PID FROM Patient WHERE userid = '{$_SESSION['userid']}'") or die(mysqli_error($conn));
//$qry2 = mysqli_num_rows($qry1);
$m1=mysqli_fetch_assoc($qry1);

$qry33 = mysqli_query($conn, "SELECT ts_slot FROM time_slots WHERE ts_sq= '$mm'") or die(mysqli_error($conn));
$qrr= mysqli_num_rows($qry33);
while ($tm=mysqli_fetch_assoc($qry33)){}



$sql = "SELECT * FROM appointment WHERE App_time='$mm' and App_date='$appdate' and DID='$m'";
  	$results = mysqli_query($conn, $sql);
  	if (mysqli_num_rows($results) > 0) {
	echo " 
	<script>
alert('The Appointment  was taken already');
 window.location.href = 'p_app.php';

</script>
";



	}
else{
$qry = mysqli_query($conn, "INSERT INTO appointment (App_Status,App_time,App_date,PID,DID)VALUES 
('S','$mm','$appdate','{$m1['PID']}','$m')");

echo "
<script>
alert('Appointment set Sucessfully');
 window.location.href = 'index.php';

</script>
";
} 






 ?>