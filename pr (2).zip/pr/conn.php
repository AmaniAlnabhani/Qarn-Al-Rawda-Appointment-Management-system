<?php

$db ='dbdip48g19'; 
$user='dip48g19';
$pass='76713971';
$hostname='localhost';
$conn = mysqli_connect($hostname,$user,
       $pass,$db) or die("<mark>Connection Error</mark>");
?>
