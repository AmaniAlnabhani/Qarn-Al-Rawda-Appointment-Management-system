<HTML><HEAD>
<TITLE>Home Page</TITLE><HEAD>
<Style type='text/css'>
body {font-family : Arial, sans-serif;font-size:10pt;
background-image:url("image/7.jpg");
  background-repeat:no-repeat;
	background-attachment: fixed;
  background-size: cover;}
table {border: black 2px solid}
td { border: black 2px solid}
</STYLE></HEAD>
<BODY>
<center><b>Qarn Al Rawda Managment System</b>
<TABLE border="1" cellspacing="5" cellpadding="5" align="center">
<FORM action="login.php" method="post">
<tr><td>User ID</td>
<td><input type="text" name="fuserid" size="15"></td></tr>
<tr><td>Password</td>
<td><input type="password" name="fuserpass" size="15">

<tr><td colspan="2" align="CENTER">
<input type="submit" name="submit" value="Login"></td></tr>
</FORM></TABLE>
<p> If you do not have an account, register <a href="register1.php">here</a></p></center>
</BODY></HTML>