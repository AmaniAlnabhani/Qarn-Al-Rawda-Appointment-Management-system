<?php  
include('conn.php');
$output = '';
 


 $query = "SELECT * FROM appointment";
 $result = mysqli_query($conn, $query);
 if(mysqli_num_rows($result) > 0)
 {
  $output .= '
   <table class="table" bordered="1">  
                    <tr>  
                         <th> appointment Id</th>  
                         <th> appointment Status</th>  
                         <th> appointment time</th>  
						  <th> appointment date</th> 
						   <th>PID</th> 
						    <th>DID</th> 
       
                    </tr>
  ';
  while($row = mysqli_fetch_array($result))
  {
   $output .= '
    <tr>  
                         <td>'.$row["AppId"].'</td>  
                         <td>'.$row["App_Status"].'</td>  
                         <td>'.$row["App_date"].'</td>  
                        <td>'.$row["PID"].'</td>  
                           <td>'.$row["DID"].'</td>
                    </tr>
   ';
  }
  $output .= '</table>';
  header('Content-Type: application/xls');
  header('Content-Disposition: attachment; filename=appointment.xls');
  echo $output;
 }

?>