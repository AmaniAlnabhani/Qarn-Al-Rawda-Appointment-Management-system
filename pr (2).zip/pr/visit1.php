<?php
include('conn.php');
include('heder.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Qarn Al Rawda : Visit</title>
	    
	<Style type='text/css'>
body {font-family : Arial, sans-serif;font-size:10pt;
background-image:url("image/144.jpg");
  background-repeat:no-repeat;
	background-attachment: fixed;
  background-size: cover;}

</STYLE>
</head>
<body>
<center>
<center><h4>visit Details</h4>
</center>
<form action="visit2.php" method="post">

<label >Visite Date 
</label>
<input type="date"  placeholder="dd/mm/yy" name="vdate" min="<?= date("Y-m-d"); ?>" max="<?= date("Y-m+1-d"); ?>" required>
<br>
<label >Select Doctor 
</label>
<?php $sql1 = mysqli_query($conn, "SELECT * FROM doctor WHERE Specialization='main'"); 
echo"<select name='m'><option value=x> -select Doctor - </option>";
while ($row1=mysqli_fetch_assoc($sql1)){
	echo"<option value={$row1['DID']}>{$row1['FirstName']}</option>";
}
echo"</select>";
echo"<br><label >Select Time 
</label><br>";
$qr = mysqli_query($conn, "SELECT * FROM time_slots order by ts_sq") or die(mysqli_error($con));
  $qrr= mysqli_num_rows($qr);
while ($tm=mysqli_fetch_assoc($qr)){
echo "<input type=radio name='ts' value='{$tm['ts_slot']}'>{$tm['ts_slot']} <br>";
}
echo"<input type='submit' name='submit' >";
?>
</center>
</body></html>
<?php include('footer.php'); ?>