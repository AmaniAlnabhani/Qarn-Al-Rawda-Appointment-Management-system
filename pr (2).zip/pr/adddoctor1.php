<html>
<?php include('heder.php');?>
<head>
    <title>Qarn Al Rawda :Add Doctor</title>


<style type="text/css">
	body{background-image:url("image/1.jpg");
	background-repeat:no-repeat;
	background-attachment: fixed;
  background-size: cover;}
	</style>
	
</head>

<body >
  <center>  

<b><h2>Add Doctor</h2></b>

<br>
<br>
<br>
<form class="appointment-form" method="post" action="adddoctor2.php">

<label >First name </label>
<input type="text"  placeholder="First name" name="fname"  required pattern="[A-Za-z]+">
<br>
<br>
<label >Last name </label>
<input type="text"  placeholder="Last name" name="lname"  required pattern="[A-Za-z]+">
<br>
<br>
<label >Civil number </label>
<input type="text"  placeholder="Civil number " name="civl"  required>
<br>
<br>
<label >Specialization</label>
<input type="text"  placeholder="Specialization"  name="ee"  required><br>
<br>
<label >Gender </label>
<select name="gnd"><option value="x"> -select Gender - </option>
<option value="M">Male </option>
<option value="F"> Female </option>
</select><br>
<br>

<label >Phone </label>
<input type="text"  placeholder="Phone No" name="phno"  required>
<br>
<br>
<label >Password </label>
<input type="password"  placeholder="Password" name="pwd"  required><br>
<br>
<input type="submit" name="submit" ></center>
<?php include('footer.php');?>
</body></html>