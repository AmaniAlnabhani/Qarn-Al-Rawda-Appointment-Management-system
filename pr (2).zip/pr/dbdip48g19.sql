-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 18, 2019 at 03:07 AM
-- Server version: 5.7.17
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbdip48g19`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `AId` int(11) NOT NULL,
  `UserName` varchar(11) NOT NULL,
  `Password` varchar(30) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`AId`, `UserName`, `Password`) VALUES
(2, 'admin123', '1234');

-- --------------------------------------------------------

--
-- Table structure for table `appointment`
--

CREATE TABLE `appointment` (
  `AppId` int(11) NOT NULL,
  `App_Status` char(1) NOT NULL,
  `App_time` time NOT NULL,
  `App_date` date NOT NULL,
  `PID` int(11) NOT NULL,
  `DID` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `appointment`
--

INSERT INTO `appointment` (`AppId`, `App_Status`, `App_time`, `App_date`, `PID`, `DID`) VALUES
(8, 'S', '00:00:01', '2019-12-26', 13, 4),
(9, 'S', '00:00:04', '2019-12-20', 13, 3),
(10, 'S', '00:00:04', '2019-12-20', 13, 3),
(11, 'S', '00:00:04', '2019-12-20', 13, 3),
(12, 'S', '00:00:01', '2019-12-18', 13, 5),
(13, 'S', '00:00:03', '2019-12-25', 14, 5),
(14, 'S', '00:00:02', '2019-12-26', 13, 5),
(15, 'S', '00:00:04', '2019-12-26', 13, 5),
(16, 'S', '00:00:04', '2019-12-26', 13, 5),
(17, 'S', '00:00:01', '2019-12-15', 13, 5),
(18, 'S', '00:00:01', '2019-12-15', 13, 5),
(19, 'S', '00:00:01', '2019-12-23', 13, 3),
(20, 'S', '00:00:05', '2019-12-22', 13, 5),
(21, 'S', '00:00:05', '2019-12-23', 13, 5),
(22, 'S', '00:00:00', '2019-12-18', 13, 5),
(23, 'S', '00:00:00', '2019-12-30', 13, 5),
(24, 'S', '00:00:00', '2019-12-30', 13, 5);

-- --------------------------------------------------------

--
-- Table structure for table `doctor`
--

CREATE TABLE `doctor` (
  `DID` int(11) NOT NULL,
  `FirstName` varchar(40) NOT NULL,
  `LastName` varchar(40) NOT NULL,
  `Gender` char(1) NOT NULL,
  `PhoneNum` varchar(11) NOT NULL,
  `Specialization` varchar(30) NOT NULL,
  `doc_civilId` int(8) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `doctor`
--

INSERT INTO `doctor` (`DID`, `FirstName`, `LastName`, `Gender`, `PhoneNum`, `Specialization`, `doc_civilId`) VALUES
(1, 'Ross ', 'Gellar', 'M', '9830768030', 'main', 333),
(2, ' tre', 'hh', 'M', '56433', 'main', 222),
(3, ' rajesh', 'rr', 'M', '5313', 'main', 111),
(4, ' amal', 'alnabhani', 'F', '9879345', 'main', 23706097),
(5, ' ali', 'ahmed', 'M', '9864345', 'dentist', 13234567),
(6, ' maha', 'ahmed', 'F', '9893889', 'main', 23761097);

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `FId` int(11) NOT NULL,
  `PID` int(11) NOT NULL,
  `Feedback` varchar(30) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`FId`, `PID`, `Feedback`) VALUES
(1, 0, 'rbfv '),
(2, 0, 'rfdssgsxd'),
(3, 0, 'wdx'),
(4, 1, 'gfrdes'),
(5, 13, 'i like this website'),
(6, 14, 'thank you ');

-- --------------------------------------------------------

--
-- Table structure for table `patient`
--

CREATE TABLE `patient` (
  `PID` int(11) NOT NULL,
  `FirstName` varchar(40) NOT NULL,
  `LastName` varchar(35) NOT NULL,
  `Gender` varchar(6) NOT NULL,
  `Age` varchar(90) NOT NULL,
  `PhoneNum` varchar(11) NOT NULL,
  `userid` int(8) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `patient`
--

INSERT INTO `patient` (`PID`, `FirstName`, `LastName`, `Gender`, `Age`, `PhoneNum`, `userid`) VALUES
(1, 'Ali', 'ahmed', 'M', '13', '97902458', 23704897),
(13, 'amani', 'alnabhani', 'F', '22', '9899323', 11111111),
(14, 'rayan', 'alnabhani', 'F', '16', '9893873', 22223);

-- --------------------------------------------------------

--
-- Table structure for table `time_slots`
--

CREATE TABLE `time_slots` (
  `ts_sq` int(3) NOT NULL,
  `ts_slot` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `time_slots`
--

INSERT INTO `time_slots` (`ts_sq`, `ts_slot`) VALUES
(1, '08:00am-08:30am'),
(2, '08:30am-09:00am'),
(3, '09:00am-09:30am'),
(4, '09:30am-10:00am'),
(5, '10:00am-10:30am');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `userid` int(8) NOT NULL,
  `usertype` char(1) NOT NULL,
  `upswd` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`userid`, `usertype`, `upswd`) VALUES
(23704897, 'P', '81dc9bdb52d04dc20036dbd8313ed055'),
(70504897, 'D', '674f3c2c1a8a6f90461e8a66fb5550ba'),
(40302010, 'A', 'ea3ed20b6b101a09085ef09c97da1597'),
(11111111, 'P', '81dc9bdb52d04dc20036dbd8313ed055'),
(23706097, 'D', '81dc9bdb52d04dc20036dbd8313ed055'),
(13234567, 'D', '81dc9bdb52d04dc20036dbd8313ed055'),
(22223, 'P', '81dc9bdb52d04dc20036dbd8313ed055'),
(23761097, 'D', '81dc9bdb52d04dc20036dbd8313ed055');

-- --------------------------------------------------------

--
-- Table structure for table `visit`
--

CREATE TABLE `visit` (
  `VId` int(11) NOT NULL,
  `V_status` int(11) NOT NULL,
  `V_time` time NOT NULL,
  `V_date` date NOT NULL,
  `PID` int(11) NOT NULL,
  `DID` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`AId`);

--
-- Indexes for table `appointment`
--
ALTER TABLE `appointment`
  ADD PRIMARY KEY (`AppId`);

--
-- Indexes for table `doctor`
--
ALTER TABLE `doctor`
  ADD PRIMARY KEY (`DID`),
  ADD UNIQUE KEY `doc_civilId` (`doc_civilId`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`FId`);

--
-- Indexes for table `patient`
--
ALTER TABLE `patient`
  ADD PRIMARY KEY (`PID`);

--
-- Indexes for table `time_slots`
--
ALTER TABLE `time_slots`
  ADD PRIMARY KEY (`ts_sq`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`userid`);

--
-- Indexes for table `visit`
--
ALTER TABLE `visit`
  ADD PRIMARY KEY (`VId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `AId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `appointment`
--
ALTER TABLE `appointment`
  MODIFY `AppId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
--
-- AUTO_INCREMENT for table `doctor`
--
ALTER TABLE `doctor`
  MODIFY `DID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `FId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `patient`
--
ALTER TABLE `patient`
  MODIFY `PID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `time_slots`
--
ALTER TABLE `time_slots`
  MODIFY `ts_sq` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `userid` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=70504898;
--
-- AUTO_INCREMENT for table `visit`
--
ALTER TABLE `visit`
  MODIFY `VId` int(11) NOT NULL AUTO_INCREMENT;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
