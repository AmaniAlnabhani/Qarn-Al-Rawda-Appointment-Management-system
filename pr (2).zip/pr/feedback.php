<?php include('heder.php');?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Qarn Al Rawda : feedback</title>
<link href="https://fonts.googleapis.com/css?family=Mouse+Memoirs|Suez+One&display=swap" rel="stylesheet">
<style type="text/css">
	label{
         font-family: 'Mouse Memoirs', sans-serif;
		 font-family: 'Suez One', serif;
		 text-size:40px;}
  body{background-image:url("image/7.jpg");
  background-repeat:no-repeat;
	background-attachment: fixed;
  background-size: cover;
  }
	</style>
	
</head>
<body>

<center>
<form action="feedback2.php" method="post">
  <div >
  <br>
  <br>
    <label >Give Us Your Feedback </label><br>
	
<textarea  name="feed"cols="40" rows="20" placeholder="Enter your feedback here" required ></textarea><br>


	<input type="submit" name="su">
  </div>

</form></center>
</body>
</html>
<?php
include('footer.php');
?>