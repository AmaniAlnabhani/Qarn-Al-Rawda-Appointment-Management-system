<html>
<head>
<style>
img{float: left;}
p{
virtical-align: middle;
top:-20;
padding: 20px 0;
}
</style>
</head>
<body>
<?php
include('conn.php');
include('heder.php');

$qry1 = mysqli_query($conn, "SELECT * FROM Patient WHERE userid = '{$_SESSION['userid']}'") or die(mysqli_error($conn));
//$qry2 = mysqli_num_rows($qry1);
$m1=mysqli_fetch_assoc($qry1); 

echo "<br><br><form method=POST action=U_data.php>";
echo "<table border=1>";
echo"<tr><td><center>";
echo "<p><b>Editing Patient Data </b></p></td></center></tr>";
echo "<tr><td>Name:</td><td>";
echo "First Name:<input type=text name='fn' value='{$m1['FirstName']}'>
Last Name:<input type=text name='ln' value='{$m1['LastName']}'></td></tr>";


echo "<tr><td>Gender:</td><td>";



$genders=['M'=>'Male','F'=>'Female'];
foreach ($genders as $k=>$v){
	echo "<input type=radio name='Gender' value='$k'";
	if($k==$genders) echo "checked";
echo ">$v ";
}
echo "</td></tr>";
echo "<tr><td>Age:</td><td>";
echo "<input type=text name='Age' value='{$m1['Age']}'>";
echo "</td></tr>";
echo "<tr><td>Phone Number:</td><td>";
echo "<input type=text name='PhoneNum' value='{$m1['PhoneNum']}'>";
echo "</td></tr>";
//echo"<input type=hidden name=ad value='$U_data'>\n";  
echo"<tr><th colspan=2><center><input type=submit style=\"border-radius: 12px; padding: 10px; 24px;\" name=save value='Save Data'></center></th></tr>\n";
echo "</table></form>";




$fnn=$_POST['fn'];
$ln=$_POST['ln'];
$Gender=$_POST['Gender'];
$Age=$_POST['Age'];
$PhoneNum=$_POST['PhoneNum'];
$q="UPDATE patient SET  FirstName='$fnn' ,LastName='$ln' ,Gender='$Gender' , Age='$Age' , PhoneNum='$PhoneNum' ";
$r=mysqli_query($conn,$q) or die ("Error in the query $q". mysqli_error($conn));
include('footer.php');
?>

</body></html>