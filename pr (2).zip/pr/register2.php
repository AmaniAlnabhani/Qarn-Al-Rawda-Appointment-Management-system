<?php 

include('conn.php');
include('mylib.php');

 $errors=array();
 if(  empty($_POST['fname'])&& empty($_POST['lname']) &&
empty($_POST['age']) && $_POST['m']=='x' && empty($_POST['phno'])&&empty($_POST['pwd'])&&
empty($_POST['civill'])){ $errors[]="Please chack "; }	
 
///////////////////////////////////////////////////////////////////////////////////////////////////////////
	session_start();
 if(count($errors) == 0) {
$fname=$_POST['fname'];
$last=$_POST['lname'];
$age=$_POST['age'];
$pho=$_POST['phno'];
$gender=$_POST['m'];
$civill=$_POST['civill'];
$password=md5($_POST['pwd']);
$query=mysqli_query($conn,"insert into patient(FirstName,LastName,Gender,Age,PhoneNum,userid) values('$fname',
'$last','$gender','$age','$pho','$civill')");
$query1=mysqli_query($conn,"insert into user(userid,usertype,upswd) values('$civill',
'P','$password')");

if($query&&$query1)
{
	echo "<script>alert('Successfully Registered. You can login now');</script>";
	header('location:login1.php');
}
}
 
 
else{DisplayErrors();}




  
?>