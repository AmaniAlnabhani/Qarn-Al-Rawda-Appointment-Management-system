
<?php

//include('conn.php');

	
echo "<a href=U_data.php$?x=AQ_x>Update Pessonal Information</a>";
?>