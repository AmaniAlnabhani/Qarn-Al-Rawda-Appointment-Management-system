<html>
<head>
<style type="text/css">
	label{
         font-family: 'Mouse Memoirs', sans-serif;
		 font-family: 'Suez One', serif;
		 text-size:40px;}
  body{background-image:url("image/8.jpg");
  background-repeat:no-repeat;
	background-attachment: fixed;
  background-size: cover;}
	</style>

</head>
<body><center>
<b><h2>Register</h2></b>
<form method="post" action="register2.php">
<label >First name 
</label>
<input type="text"  placeholder="First name" name="fname"  required pattern="[A-Za-z]+">

<br>
<label >Last name </label>
<input type="text"  placeholder="Last name" name="lname"  required pattern="[A-Za-z]+">
<br>

<label >Age </label>
<input type="text"  placeholder="Age"  name="age"  required>
<br>
<label >Gender </label>
<select name="m"><option value="x"> -select Gender - </option>
<option value="M">Male </option>
<option value="F"> Female </option>
</select>
<br>
<label >Phone </label>
<input type="text"  placeholder="Phone No" name="phno"  required>
<br>
<label >Civill number </label>
<input type="text"  placeholder="Civill number" name="civill"   required pattern="[0-9]+">
<br>
<label >Password </label>
<input type="password"  placeholder="Password" name="pwd"  required>
<br>
<input  name="ok" type="submit">
</form></center>
</body>
</html>
