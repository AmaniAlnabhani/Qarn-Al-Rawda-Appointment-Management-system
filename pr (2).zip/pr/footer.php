<?php
echo"<html><head>
<style>  #footer{
 margin-top: 30px;
 font-size:20px;
 clear:left;
 border:double 3px #bbb; /*border-top:dashed 1px #CCC;*/
 padding:20px;
 background: #f6f6ee url('images/bck.jpg');
 border-radius: 20px;
 }
 #footer .developer {
 color:#068;
 }
</style>
<head>";
 echo "</div>"; // closing tag for **content** division
 echo "<div id='footer'>
 &copy; Copyright ". date('Y');
 echo " All rights reserved - This web site was developed by ";
 echo "<span class='developer'>  Amani & Abir</span>
 </div>";
 echo "</div>"; // closing tag for main **container** division
echo "</body></html>";
 ?>

