
<html>
<body>
<style type="text/css">
h2{font-family: 'Trocchi', serif;
font-size:40px;}
a{
font-family: 'Oswald', sans-serif;
font-family: 'Roboto Slab', serif;}

.dropbtn {
  background-color: #4CAF50;
  color: white;
  padding: 16px;
  font-size: 16px;
  border: none;
}

.dropdown {
  position: relative;
  display: inline-block;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f1f1f1;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
}

.dropdown-content a:hover {background-color: #ddd;}

.dropdown:hover .dropdown-content {display: block;}

.dropdown:hover .dropbtn {background-color: #3e8e41;}




</style>
</body>
</html>
<?php
session_start();
 if ($_SESSION['type'] == "P") {
    ?>
	
	<h2> &nbsp;  &nbsp;Qarn Al Rawda</h2>&nbsp; &nbsp; 
	<b><p style="float:  right;  ">
     <a href="visit1.php">visite</a> &nbsp; &nbsp;  &nbsp; &nbsp; 
	<a href="p_app.php"> Appointments</a> &nbsp; &nbsp;  &nbsp; &nbsp; 
	<a href="U_data.php">Update information</a> &nbsp; &nbsp;  &nbsp; &nbsp;
	<a href="feedback.php">Feedback</a> &nbsp; &nbsp;  &nbsp; &nbsp;
	<a href="logout.php">Log out</a> 
	</p></b>
<?php
} else if ($_SESSION['type'] == "A") {
    ?>
	<h2> &nbsp;  &nbsp;Qarn Al Rawda</h2>&nbsp; &nbsp; 
	<p style="float:right;">

	<a href="adddoctor1.php">Add Doctor</a> &nbsp; &nbsp;  &nbsp; &nbsp; 
	<a href="logout.php">Log out</a> &nbsp; &nbsp;  &nbsp; &nbsp;
	<div class="dropdown" style="float:right;">
  <button  > report</button>
  <div class="dropdown-content">
    <a href="patient_report.php">patient</a>
 
    <a href="app_report.php">appointment</a>
  </div>
</div>
	</p>
<?php
} else if ($_SESSION['type'] == "D") {
	
    ?>
	<h2> &nbsp;  &nbsp;Qarn Al Rawda</h2>&nbsp; &nbsp; 
	
   <p style="float:  right;"> <a href="appointments2.php">My Appointments</a>
   &nbsp; &nbsp;  &nbsp; &nbsp; <a href="logout.php">Log out</a></p>
<?php
}
