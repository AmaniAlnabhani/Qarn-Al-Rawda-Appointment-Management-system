<?php
include('conn.php');

include('mylib.php');


if(empty($_POST['feed']))
	$errors[]="Please write your feedback"; 

///////////////////////////////////////////////////////////////////////////////////////////////////////////
	session_start();
 if(count($errors) == 0) {
 
 $feed=$_POST['feed'];
 $qry1 = mysqli_query($conn, "SELECT PID FROM Patient WHERE userid = '{$_SESSION['userid']}'") or die(mysqli_error($conn));

$m=mysqli_fetch_assoc($qry1);

$query=mysqli_query($conn,"insert into feedback (PID,Feedback) values ('{$m['PID']}','$feed')")or die(mysqli_error($conn));
	
	

 echo "
 <script>
 alert('save  Successfullly');
 window.location.href = 'index.php';
 </script>";


            }
else{DisplayErrors();}
?>
