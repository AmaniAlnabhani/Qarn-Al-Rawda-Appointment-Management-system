<?php
include('conn.php');
include('mylib.php');
session_start();

$errors=[];
 if( empty($_POST['appdate'])
 && $_POST['m']=='x' && isset($_POST['ts'])){ $errors[]="Please chack "; }
{ $errors[]="Please chack"; }

$stat=['C'=>'complet','S'=>'Still'];



$qq=$_POST['ts'];
$vv=$_POST['m'];

$vdate = $_POST['vdate'];		
 $qry1 = mysqli_query($conn, "SELECT PID FROM Patient WHERE userid = '{$_SESSION['userid']}'") or die(mysqli_error($conn));

$m1=mysqli_fetch_assoc($qry1);

$qry33 = mysqli_query($conn, "SELECT ts_slot FROM time_slots WHERE ts_sq= '$qq'") or die(mysqli_error($conn));
$qrr= mysqli_num_rows($qry33);
while ($tm=mysqli_fetch_assoc($qry33)){}



$sql = "SELECT * FROM visit WHERE V_time='$qq' and V_date='$vdate' and DID='$vv'";
  	$results = mysqli_query($conn, $sql);
  	if (mysqli_num_rows($results) > 0) {
	echo " 
	<script>
alert('The visit  was taken already');
 window.location.href = 'visit1.php';

</script>
";



	}
else{
$qry = mysqli_query($conn, "INSERT INTO visit (V_status,V_time,V_date,PID,DID) VALUES 
('S','$qq','$vdate','{$m1['PID']}','$vv')");

echo "
<script>
alert('visit set Sucessfully');
 window.location.href = 'index.php';

</script>
";
}





 ?>