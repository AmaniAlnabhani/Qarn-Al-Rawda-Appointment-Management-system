<?php
include('heder.php');
?>
<html><head>
<link href="https://fonts.googleapis.com/css?family=Exo+2|Nunito+Sans&display=swap" rel="stylesheet">
<style type="text/css">
	
  body{background-image:url("image/77.jpg");
  background-repeat:no-repeat;
	background-attachment: fixed;
  background-size: cover;
   background-image-opacity: 0.5;}
  h3{font-family:  sans-serif;
}
	</style>
</head>
<body>
<br>
<br>
<br>
<br>
<br>
<br><center>
<h3>Health is "a state of complete physical, mental, and social well-being and not merely the absence of disease" 
according to the World Health Organization (WHO). Physical is about the body. Mental is about how people think 
and feel. Social talks about how people live with other people. It is about family, work, school, and friends.</h3>
</center>
<h3 class="mb-4">Location</h3>
<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3673.4546985374136!2d57.54594688587354!3d22.970301324045675!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3e8ef1da6a00db73%3A0x1093293fc5ae9516!2z2LnZitin2K_YqSDZgtix2YYg2KfZhNix2YjYttip!5e0!3m2!1sar!2som!4v1573914895653!5m2!1sar!2som" width="200" height="200" frameborder="0" style="border:0;" allowfullscreen=""></iframe>
<br>
<br>
<br>
<br>


</body>
</html>

<?php
include('footer.php');
?>