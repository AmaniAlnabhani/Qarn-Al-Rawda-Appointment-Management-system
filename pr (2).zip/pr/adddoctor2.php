<?php

    include('conn.php');
	include('mylib.php');

 $errors=array();
 if( empty($_POST['fname'])&& empty($_POST['lname']) &&
empty($_POST['ee']) && $_POST['gnd']=='x' && empty($_POST['phno'])&&empty($_POST['pwd'])&&
empty($_POST['civill'])){ $errors[]="Please chack "; }
/////////////////////////////////////////////////
  	session_start();
 if(count($errors) == 0) {
 $fname = ucfirst($_POST['fname']);
        $lname =  ucfirst($_POST['lname']);
        $gnd = $_POST['gnd'];
		$s = strtolower($_POST['ee']);
		$phno = $_POST['phno'];
        $phno = $_POST['phno'];
        $pwd = md5($_POST['pwd']);
		 $civl = $_POST['civl'];
		 ///////////////////////////////////////////////
		 $qry2 = mysqli_query($conn, "INSERT INTO user (userid, usertype, upswd)
VALUES (' $civl',  'D','$pwd')") or die(mysqli_error($conn));
		 //////////////////////////////////////////////////////////////////////
        $qry3 = mysqli_query($conn, "INSERT INTO doctor (FirstName,LastName, Gender, PhoneNum, Specialization,doc_civilId)
VALUES (' $fname', '$lname', '$gnd','$phno', '$s',' $civl')") or die(mysqli_error($conn));
echo '
<script>
alert("save  Successfullly");
window.location.href = "login1.php";
</script>';
} else {
echo '
<script>
alert(" dont save");
</script>';
}
  

 ?>
