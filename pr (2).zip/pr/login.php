
<?php include "conn.php";
include "error.php";
$errors=[];

if(empty($_POST['fuserid']))
$errors[]="Correct Student ID ....... ";

if(empty($_POST['fuserpass']))
$errors[]="Enter PASSWORD ";

$userid=$_POST['fuserid'];
$pass=$_POST['fuserpass'];
$encrypted_mypassword=md5($pass);
// select from user table
$sql = "SELECT * FROM user WHERE userid='$userid' AND upswd='$encrypted_mypassword' ";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
	$row = $result->fetch_assoc();
	session_start();
	$_SESSION['userid']=$row["userid"];
	$_SESSION['fullname']= $row["fname"]." ".$row["lname"];
	$_SESSION['type']=$row["usertype"];
	//Move and open the appropriate page
header("Location: index.php");}

 else { // it means mysqli_num_rows == 0 wrong user id or password
 // login/pass check failed
 // redirect to error page
 header("location: error.php?ec=0");
 exit;
 }


?>