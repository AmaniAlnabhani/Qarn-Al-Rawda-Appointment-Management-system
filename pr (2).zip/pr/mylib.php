<?php

 function DisplayErrors(){
 global $errors;
 
 echo "<ol>";
 foreach($errors as $k => $v) {
 echo"<li>$v</li>";
 }
 echo "</ol>";
 
 echo "<p style='text-align:center;
margin:20px 130px; backgroundcolor:#F00;'>
 <a href=index.php >click here to correct the errors</a></p>";
 }
 ?>
