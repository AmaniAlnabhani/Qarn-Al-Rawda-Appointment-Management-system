<?php
include('conn.php');
include('heder.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Qarn Al Rawda : Appointments</title>
	<Style type='text/css'>
body {font-family : Arial, sans-serif;font-size:10pt;
background-image:url("image/166.jpg");
  background-repeat:no-repeat;
	background-attachment: fixed;
  background-size: cover;}

</STYLE>
</head>
<body>
<center><b>
<h4 > Appoinment Details</h4>

<form action="p_app2.php" method="post">

<label >Appointment Date 
</label>
<input type="date"  placeholder="dd/mm/yy" name="appdate" min="<?= date("Y-m-d"); ?>" max="<?= date("Y-m+1-d"); ?>" required>
<br>
<label >Select Doctor 
</label>
<?php $sql1 = mysqli_query($conn, "SELECT * FROM doctor WHERE Specialization='dentist'"); 
echo"<select name='m'><option value=x> -select Doctor - </option>";
while ($row1=mysqli_fetch_assoc($sql1)){
	$v=$row1['DID'];
	echo"<option value='$v'>{$row1['FirstName']}</option>";
}
echo"</select>";

echo"<br><label ><br>Select Time 
</label><br>";

$qr = mysqli_query($conn, "SELECT * FROM time_slots order by ts_sq") or die(mysqli_error($conn));
  $qrr= mysqli_num_rows($qr);
while ($tm=mysqli_fetch_assoc($qr)){
echo "<input type=radio name='ts' value='{$tm['ts_slot']} '>{$tm['ts_slot']} <br>";
}
echo"<button  name=' chack' >save </button>";
?>
<input type="hidden" name="type" value="doctor"></b></center>
</body></html><br>
<br>
<br>
<br>


 
 <?php include('footer.php');?>