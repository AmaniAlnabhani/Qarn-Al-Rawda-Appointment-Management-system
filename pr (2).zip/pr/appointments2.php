<!DOCTYPE html>
<html lang="en">
<head>
    <title>Qarn Al Rawda : Appointments</title>
	<Style type='text/css'>
body {font-family : Arial, sans-serif;font-size:10pt;
background-image:url("image/33.jpg");
  background-repeat:no-repeat;
	background-attachment: fixed;
  background-size: cover;}

</STYLE>
</head>
</html>



<?php
include('conn.php');
include('mylib.php');
include('heder.php');





$stat=['C'=>'complet','S'=>'Still'];		
 $qry1 = mysqli_query($conn, "SELECT *  FROM doctor  WHERE doc_civilId = '{$_SESSION['userid']}'") or die(mysqli_error($conn));

$m1=mysqli_fetch_assoc($qry1);
echo"<h3>  Appointment/Visit for DR:{$m1['FirstName']} {$m1['LastName']}</h3>";

$qry11 = mysqli_query($conn, "SELECT *  FROM appointment  WHERE DID = '{$m1['DID']}' ") or die(mysqli_error($conn));
$qrr= mysqli_num_rows($qry11);
if($qrr!=0){
echo"<h3> ALL Appointment </h3>";
echo"<table style='width:100%' border='1'>
  <tr>
    <th>Time</th>
    <th>Date</th>
    <th>PID</th>
  </tr>";
while( $m11=mysqli_fetch_assoc($qry11)){
  
  echo"<tr>
    <td>{$m11['App_time']}</td>
    <td>{$m11['App_date']}</td>
    <td>{$m11['PID']}</td>
</tr>";}
 
echo"</table>";
}
else{

echo"<h3> ALL Visit </h3>";

echo"<table style='width:100%' border='1'>
  <tr>
    <th>Time</th>
    <th>Date</th>
    <th>PID</th>
  </tr>";

	$qry4 = mysqli_query($conn, "SELECT *  FROM visit  WHERE DID = '{$m1['DID']}' order by VId") or die(mysqli_error($conn));
//$qry2 = mysqli_num_rows($qry1);
while($w22=mysqli_fetch_assoc($qry4)){
	echo"<tr>
    <td>{$w22['V_time']}</td>
    <td>{$w22['V_date']}</td>
    <td>{$w22['PID']}</td>
</tr>";}
 
echo"</table>";
}
	include('footer.php');

?>